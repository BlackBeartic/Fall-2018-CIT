<?php
include_once("classes/user.class.php");
include_once("classes/RegisteredUser.class.php");
include_once("classes/Admin.class.php");


$registered = new RegisteredUser ("Regular User", 1);
$admin = new Admin ("Admin", 2);

$registered -> $first_name = "Patrick";
$registered -> $last_name = "Rudolph";
$registered -> $user_type = "Normal";
$registered -> $email_address = "N/A";

$admin-> $first_name = "Patrick";
$admin-> $last_name = "Rudolph";
$admin-> $user_type = "Admin";
$admin-> $email_address = "N/A";

echo "First Name: " . $registered->$first_name;
echo "Last Name: " . $registered -> $last_name;
echo "User Type: " . $registered -> $user_type;
echo "Email: " . $registered -> $email_address;

echo "First Name: " . $admin->$first_name;
echo "Last Name: " . $admin -> $last_name;
echo "User Type: " . $admin -> $user_type;
echo "Email: " . $admin -> $email_address;



?>
