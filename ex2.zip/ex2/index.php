<?php
include_once("classes/user.class.php");
include_once("classes/RegisteredUser.class.php");
include_once("classes/Admin.class.php");


$rUser = new RegisteredUser ('Regular User', 'BlackBeartic');
$Admin = new Admin ('Administrator', 'BlackBeartic2');

$rUser->first_name = 'Patrick';
$rUser->last_name = 'Rudolph';
$rUser->email_address = 'patrudol@iu.edu';



$Admin->first_name = 'Patrick';
$Admin->last_name = 'Rudolph';
$Admin->email_address = 'patrudol@iu.edu';

echo "First Name: ". $rUser->first_name . "</br>";
echo "Last Name: ". $rUser->last_name . "</br>";
echo "Username: ". $rUser->user_id . "</br>";
echo "User Level:  ". $rUser->user_level . "</br>";
echo "User Type:  ". $rUser->user_type . "</br>";
echo "</br>";
echo "</br>";

echo "First Name: ". $Admin->first_name . "</br>";
echo "Last Name: ". $Admin->last_name . "</br>";
echo "Username: ". $Admin->user_id . "</br>";
echo "User Level:  ". $Admin->user_level . "</br>";
echo "User Type:  ". $Admin->user_type . "</br>";




?>
