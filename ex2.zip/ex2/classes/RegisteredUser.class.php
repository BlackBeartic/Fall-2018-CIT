<?php
class RegisteredUser extends user {

  public function __construct($level){
    parent::__construct($user_level);
    $this->user_level = $level;
  }

  public function __set($user_level, $user_id) {
    $this->$user_level = $user_id;
    return;
  }

  public function __get($user_level) {
    return $this->$user_level;
  }
}


?>
