<?php

define('ABSOLUTE_PATH', '/home/patrudol/htdocs/a1/Debug-Exercise-master');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:23711/a1/Debug-Exercise-master');
