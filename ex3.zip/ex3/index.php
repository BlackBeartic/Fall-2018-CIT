<?php
/*include_once("classes/user.class.php");
include_once("classes/RegisteredUser.class.php");
include_once("classes/Admin.class.php");
*/

function myLoad($class){
  include_once ('classes/'.$class. '.class.php');
}
spl_autoload_register('myLoad');


$rUser = new RegisteredUser ('Regular User', 'BlackBeartic');
$Admin = new Admin ('Administrator', 'BlackBeartic2');

$rUser->first_name = 'Patrick';
$rUser->last_name = 'Rudolph';
$rUser->email_address = 'patrudol@iu.edu';



$Admin->first_name = 'Patrick';
$Admin->last_name = 'Rudolph';
$Admin->email_address = 'patrudol@iu.edu';

echo "First Name: ". $rUser->first_name . "</br>";
echo "Last Name: ". $rUser->last_name . "</br>";
echo "Username: ". $rUser->user_id . "</br>";
echo "User Level:  ". $rUser->user_level . "</br>";
echo "User Type:  ". $rUser->user_type . "</br>";


echo "<hr/>";

echo "First Name: ". $Admin->first_name . "</br>";
echo "Last Name: ". $Admin->last_name . "</br>";
echo "Username: ". $Admin->user_id . "</br>";
echo "User Level:  ". $Admin->user_level . "</br>";
echo "User Type:  ". $Admin->user_type . "</br>";

echo "<hr/>";

$add = RegisteredUser::mathAdd(8,4);

echo $add . " is the combined total";

echo "<hr/>";

$fname=$_POST["First Name"];
$lname=$_POST["Last Name"];
$email=$_POST["Email"];
?>

<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body>
<form action="" method="post">
First Name:
<input type="text" name= "First Name">
<?php echo "</br>" ?>
Last Name:
<input type="text" name= "Last Name">
<?php echo "</br>" ?>
Email:
<input type="text" name= "Email">
<?php echo "</br>" ?>

<input type="submit" name = "submit">

</body>
</html>
