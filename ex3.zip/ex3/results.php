<?php
class RegisteredU {
  public function RegisteredUser ($newUser, $regular) {

  }
}

?>
