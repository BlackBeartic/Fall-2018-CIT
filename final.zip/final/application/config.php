<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23711/final/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'patrudol');
define('DB_PASS', '1705');
define('DB_NAME', 'patrudol_db');

define('REQFIELD', '<font color="#FF0000">*</font>');
?>
